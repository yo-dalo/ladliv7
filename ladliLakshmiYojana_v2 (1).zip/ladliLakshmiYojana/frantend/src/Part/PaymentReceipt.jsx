import React from 'react';

const PaymentReceipt = ({ paymentData }) => {
  if (!paymentData) {
    return <div className="text-center p-4">No Payment Data Available</div>;
  }

  const {
    PaymentId,
    PlanId,
    UserId,
    bank_reference,
    cf_payment_id,
    gateway_name,
    gateway_order_id,
    gateway_payment_id,
    is_captured,
    order_amount,
    order_currency, // Missing in original response, assuming its defined elsewhere
    order_id,
    payment_completion_time,
    payment_currency,  // Missing in original response, assuming its defined elsewhere
    payment_group,
    payment_message,
    payment_method,
    payment_status,
    payment_time,
    Address,
    Email,
    Phone,
    PlanDuration,
    PlanFee,
    PlanInformation,
    PlanName,
    PlanReturnPrice,
    UserName
  } = paymentData;


  return (
    <div className="max-w-2xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gray-100 px-6 py-4 border-b border-gray-200">
        <h2 className="text-2xl font-semibold text-gray-800">Payment Receipt</h2>
      </div>

      {/* Content */}
      <div className="p-6">

        {/* User Information */}
        <div className="mb-4">
            <h3 className="text-lg font-medium text-gray-700 mb-2">User Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-gray-600">Name:</p>
                <p className="font-medium">{UserName}</p>
              </div>
              <div>
                <p className="text-gray-600">Email:</p>
                <p className="font-medium">{Email}</p>
              </div>
              <div>
                <p className="text-gray-600">Phone:</p>
                <p className="font-medium">{Phone}</p>
              </div>
              <div>
                <p className="text-gray-600">Address:</p>
                <p className="font-medium">{Address}</p>
              </div>
            </div>
        </div>

        {/* Order Information */}
        <div className="mb-4">
          <h3 className="text-lg font-medium text-gray-700 mb-2">Order Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600">Order ID:</p>
              <p className="font-medium">{PaymentId}</p>
            </div>
            <div>
              <p className="text-gray-600">Plan ID:</p>
              <p className="font-medium">{PlanId}</p>
            </div>
            <div>
              <p className="text-gray-600">User ID:</p>
              <p className="font-medium">{UserId}</p>
            </div>
            <div>
              <p className="text-gray-600">Plan Name:</p>
              <p className="font-medium">{PlanName}</p>
            </div>
            <div>
              <p className="text-gray-600">Plan Duration:</p>
              <p className="font-medium">{PlanDuration} </p>
            </div>
          </div>
        </div>

        {/* Payment Details */}
        <div className="mb-4">
          <h3 className="text-lg font-medium text-gray-700 mb-2">Payment Details</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600">Amount:</p>
              <p className="font-medium">
                {order_amount}{payment_currency || order_currency || "INR"}
              </p>
            </div>
            <div>
              <p className="text-gray-600">Status:</p>
              <p className="font-medium">{payment_status}</p>
            </div>
            <div>
             <p className="text-gray-600">Payment Time:</p>
             <p className="font-medium">{payment_time}</p>
           </div>
           <div>
             <p className="text-gray-600">Plan Fee:</p>
             <p className="font-medium">{PlanFee}</p>
           </div>
           <div>
             <p className="text-gray-600">Plan Return Price:</p>
             <p className="font-medium">{PlanReturnPrice}</p>
           </div>

          </div>
        </div>

        {/* Additional Information */}
        <div>
          <h3 className="text-lg font-medium text-gray-700 mb-2">Additional Information</h3>
          <div className="grid grid-cols-1 gap-4">
            <div>
              <p className="text-gray-600">Plan Information:</p>
              <p className="font-medium">{PlanInformation}</p>
            </div>
            {payment_message && (
               <div>
                 <p className="text-gray-600">Payment Message:</p>
                 <p className="font-medium">{payment_message}</p>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-100 px-6 py-4 border-t border-gray-200 text-right">
        <p className="text-sm text-gray-500">
          Generated on: {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
};

export default PaymentReceipt;