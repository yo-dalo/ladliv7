import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../Context";

const ProtectedRoute = ({ children }) => {
  const { x, loadingchacker } = useContext(AuthContext);

  if (loadingchacker) {
    return <div className="justify-center bg-white relative z-[99999999999999999999999] w-screen h-screen items-center flex"> loading........…. </div>; // Ya koi loader dikhao
  }

  if (!x?.isLogin) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default ProtectedRoute;