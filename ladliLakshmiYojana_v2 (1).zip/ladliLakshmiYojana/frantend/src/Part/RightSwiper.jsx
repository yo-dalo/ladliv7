import React from 'react'
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/scrollbar';
import 'swiper/css/pagination';
import { Autoplay, Pagination, Navigation ,Scrollbar} from 'swiper/modules';


import img1 from '../images/rightScollerImg/images.jpeg'
import img2 from '../images/rightScollerImg/images (1).jpeg'
import img3 from '../images/rightScollerImg/images (2).jpeg'

const RightSwiper = () => {
  return (
    <div className="w-full bg-amber-950 h-full">
    
        <Swiper 
    
    
    //onSlideChange={(e) => (setText(scrollertext[e.activeIndex]))}
    
    
    spaceBetween={30}
        direction={'horizontal'}
        centeredSlides={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: true,
        }}
        
        navigation={true}
        pagination={true}
       modules={[Pagination, Navigation,Autoplay]}
        //modules={[Pagination]}
    
    
    
        
        className="mySwiper flex w-full h-full bg-amber-300"
      >
        <SwiperSlide className="w-full flex justify-center items-center relative h-full bg-amber-300">
        <img className="w-full h-full object-cover" src={img1} />
        </SwiperSlide>
       
              <SwiperSlide className="w-full flex justify-center items-center relative h-full bg-amber-300">
        <img className="w-full h-full object-cover" src={img2} />
        </SwiperSlide>
       
               <SwiperSlide className="w-full flex justify-center items-center relative h-full bg-amber-300">
        <img className="w-full h-full object-cover" src={img3} />
        </SwiperSlide>
       
       
       
       
      </Swiper>
    
    
    
    
    </div>
  )
}

export default RightSwiper