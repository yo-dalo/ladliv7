import React, { useState, useContext, useEffect } from 'react';
import {myToast} from '../Toast';
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { AuthContext } from '../Context';
const Logout = ({ className }) => {
 const { clearX } = useContext(AuthContext);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    
    if(!confirm("Logout")) return;
    
    setIsLoggingOut(true);
    try {
      const response = await axios.post(
        import.meta.env.VITE_API_URL + "/api/logout/",
        {},
        { withCredentials: true }
      );
      if (response.status === 200) {
        clearX();
        myToast.info("Logout")
        navigate("/login");
      }
    } catch (err) {
      
      myToast.info("Logout failed. Please try again.");
    } finally {
      setIsLoggingOut(false);
    }
  };

  return (
    <div onClick={handleLogout} className={className}>
      {isLoggingOut ? "Logging out..." : "Logout"}
    </div>
  );
};

export default Logout;