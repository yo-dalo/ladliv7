import React, { useState, useEffect } from "react";
import axios from "axios";
import PaymentReceipt from "../Part/PaymentReceipt"; // Import the component

const MyPlans = () => {
  const [paymentData, setPaymentData] = useState(null); // State to store payment data

  const getMyPlans = () => {
    axios
      .get(import.meta.env.VITE_API_URL + "/api/show/user/paymentpeceipt", {
        withCredentials: true,
      })
      .then((response) => {
        console.log(response.data); // Log the first payment data
        setPaymentData(response.data.message[0]); // Set the payment data state
      })
      .catch((error) => {
        console.error("Error fetching payment info:", error);
      });
  };

  useEffect(() => {
    getMyPlans();
  }, []);

  return (
    <>
      <PaymentReceipt paymentData={paymentData} />  {/* Pass the data to the component */}
    </>
  );
};

export default MyPlans;