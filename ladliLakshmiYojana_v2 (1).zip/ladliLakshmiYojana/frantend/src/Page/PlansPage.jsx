import Plans from "../Part/Plans"
import Nav2 from "../Part/Nav2"
import Footer from "../Part/Footer"

const PlansPage= ()=>{
  return (
    <>
    
    
    <Nav2 />
    <Plans />
    <Footer />
    
    
    </>

    
    );
}


export default  PlansPage;