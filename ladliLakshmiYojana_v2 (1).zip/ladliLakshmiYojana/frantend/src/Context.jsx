import React, { createContext, useState, useEffect } from "react";

import axios from "axios";

// Create the context
export const AuthContext = createContext();

// Provide the context
export const AuthProvider = ({ children }) => {

  const [loadingchacker, setLoadingchacker] = useState(true);
  const [loading, setLoading] = useState(false);
  
  const [delectcommeny, setDelectcommeny] = useState(0);
  
  

  
  
  const [x, setX] = useState({
userId: null,
name: "",
phone: "",
detailsId: null,
isLogin:false

  });

  
  
 const clearX = ()=>{
    setX(x => ({ ...x, userId: null }));
    setX(x => ({ ...x, name: ""}));
    setX(x => ({ ...x, phone: "" }));
   setX(x => ({ ...x, isLogin: false}));
    
  }
  
  
  

  useEffect(() => {
    
    
    chacker()
    
  }, []);
  
  
  
  
  
  
  
  
  



const chacker = () => {
  setLoading(true)
    axios.get(import.meta.env.VITE_API_URL + '/api/verify/user/cookia', { withCredentials: true })
        .then((response) => {
setX(x => ({ ...x, userId: response.data.userId }));
setX(x => ({ ...x, name: response.data.name }));
setX(x => ({ ...x, phone: response.data.phone }));
setX(x => ({ ...x, isLogin: true}));
          
    setLoadingchacker(false)     
      setLoading(false)
          
      
        })
        .catch((error) => {

          clearX()
          //  setUser(null);                  // Set user to null in case of error
            //console.log("Error fetching user data: chacker"); // Log the error
            //return false;       
            setLoading(false)// Return false to indicate failure
           setLoadingchacker(false)
        });
};












  return (
    <AuthContext.Provider value={{
  
      loading,setLoading,
      delectcommeny,setDelectcommeny,x,setX,clearX,
      loadingchacker,setLoadingchacker,
      
    }}>
      {children}
    </AuthContext.Provider>
  );
};