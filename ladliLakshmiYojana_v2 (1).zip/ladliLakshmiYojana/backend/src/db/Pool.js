const mysql = require('mysql2');
const config = require('../config/env');
const isProduction = config.deploy === 'deploy';

const pool = mysql.createPool({
  host: !isProduction?"127.0.0.1" : config.host ,// Replace with your MySQL host
  user: !isProduction?"root" : config.user  ,  // Replace with your MySQL username
  password:!isProduction?"root" : config.password  ,   // Replace with your MySQL password
  database:!isProduction?"Org" : config.database  ,// Replace with your MySQL database name
  connectionLimit: 500,
});

module.exports = pool;