


const db = require('../db/Conn.js');

const phoneNumberIsExist = (req, res, next) => {
    const { phone } = req.body;

    // Check if phone is provided
    if (!phone) {
        return res.status(400).json({ error: "Phone number is required" });
    }

    const fetchOtpSql = "SELECT Phone FROM Users WHERE Phone = ?";
    db.query(fetchOtpSql, [phone], (err, phoneresult) => {
        if (err) { 
            console.error('Database query error:', err);
            return res.status(500).json({ message: "Error creating poster", error: err.message });
        }

        // If phone number doesn't exist in the database
        if (phoneresult.length === 0) {
            return res.status(400).json({ error: "Phone number not found" });
        }

        // Phone number exists, proceed to the next middleware
        next();
    });
}

module.exports = { phoneNumberIsExist };