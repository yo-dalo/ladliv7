// Required modules
const db = require('../db/Conn.js');
const moment = require('moment');

// Middleware to check if OTP is valid
const chackOtpIs_Valid = (req, res, next) => {
    const { phone } = req.body;

    // SQL query to fetch OTP and Expiry time
    const fetchOtpSql = "SELECT otp, Expiry FROM Otp WHERE Phone_number = ?";
    db.query(fetchOtpSql, [phone], (err, otpResults) => {
        
        // Error handling for database query
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ message: "Error mysqli", error: err.message });
        }

        // Check if OTP result exists and Expiry field is present
        if (otpResults && otpResults.length > 0 && otpResults[0].Expiry) {
            const { Expiry: expiry } = otpResults[0];

            // Check if OTP is expired
            const now = moment();
            const expiryTime = moment(expiry);

            if (!now.isAfter(expiryTime)) {
                const duration = moment.duration(expiryTime.diff(now));
                const minutes = Math.floor(duration.asMinutes());
                const seconds = Math.floor(duration.asSeconds() % 60);

                return res.status(400).json({ 
                    error: `wait ${minutes} minutes and ${seconds} seconds`
                });
            }
            // If OTP is expired, proceed to the next middleware or route handler
            next();
        } else {
            // If no OTP found or Expiry is missing
            return res.status(400).json({ 
                error: 'OTP not found or Expiry field is missing'
            });
        }
    });
}

module.exports = { chackOtpIs_Valid };