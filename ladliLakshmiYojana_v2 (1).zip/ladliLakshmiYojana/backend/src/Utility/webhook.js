const express = require('express');
const config = require('../config/env');
const crypto = require('crypto');
const db = require('../db/Conn.js');
const router = express.Router();


 



function verify(ts, rawBody){
    const body = ts + rawBody
    const secretKey = config.cashfreeXClientSecret;
    let genSignature = crypto.createHmac('sha256',secretKey).update(body).digest("base64");
    return genSignature
}


router.post('/webhook', (req, res) => {
  const secretKey =  config.cashfreeXClientSecret;
  
  const ts = req.headers["x-webhook-timestamp"]
    const signature = req.headers["x-webhook-signature"]
    const genSignature = verify(ts, req.rawBody)
    
    if(signature === genSignature){
const data = req?.body;
console.log(data);
const order = req?.body?.data?.order;
const payment = req?.body?.data?.payment;
const customer_details = req?.body?.data?.customer_details;
const payment_gateway_details = req?.body?.data?.payment_gateway_details;
        
  try {
    const query = `
      UPDATE Payments 
      SET 
        payment_method = ?, 
        is_captured = ?, 
        payment_completion_time = ?, 
        payment_currency = ?, 
        bank_reference = ?, 
        cf_payment_id = ?, 
        order_amount = ?, 
        gateway_name = ?, 
        gateway_order_id = ?, 
        gateway_payment_id = ?, 
        payment_group = ?, 
        payment_message = ?, 
        payment_status = ?, 
        payment_time = ? 
      WHERE 
        UserId = ? 
        AND order_id = ?
    `;

        const values = [

      JSON.stringify(payment.payment_method),
      data.is_captured ? 1 : 1,
      payment.payment_time,
      payment.payment_currency,
      payment.bank_reference,
      payment.cf_payment_id,
      order.order_amount,
      payment_gateway_details.gateway_name,
      payment_gateway_details.gateway_order_id,
      payment_gateway_details.gateway_payment_id,
      payment.payment_group,
      payment.payment_message,
      payment.payment_status,
      payment.payment_time,
      customer_details.customer_id || user, // Replace with actual UserId from your system if available
      //data.PlanId || PlanId || 1, // Replace with actual PlanId from your system if available
      order.order_id,
    ];

    // Update data in the database
    db.query(query, values, (err, result) => {
      if (err) {
        console.log({ error: 'Database error', details: err.message });
        return res.status(500).json({ error: 'Database error', details: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'No matching record found to update' });
      }
            console.log("all dune");
    ///  res.json({ message: 'Payment updated successfully', result });

    });

  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch order or update payment', details: error.message });
    console.log("err in try");
  }
    //res.sendStatus(200);
    
  } else {
    res.sendStatus(410);
    console.log('not ok verifyWebhookSignature');
  }
});







module.exports = router;