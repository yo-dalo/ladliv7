const express = require('express');
const config = require('../config/env');
const crypto = require('crypto');
const {addPayment} = require('../Controllers/PaymentController/AddPayment.js');
const {planAlreadyPurchased} = require('../Controllers/PlanContorller/PlanAllReadyParched.js');
const db = require('../db/Conn.js');
const {userAuth} =require("./auth");
const {userDetailsExist} =require("./userDetailsExist");
const {
  Cashfree
} = require('cashfree-pg');
const axios = require('axios');
const router = express.Router();


 Cashfree.XClientId = config.cashfreeXClientId;
Cashfree.XClientSecret = config.cashfreeXClientSecret;
Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;





function generateOrderId() {
  const uniqueId = crypto.randomBytes(16).toString('hex'); const hash = crypto.createHash('sha256');
  hash.update(uniqueId); const orderId = hash.digest('hex'); return orderId.substr(0, 12);}
  
  
router.post('/payment/test/v5', userAuth, userDetailsExist,async (req, res) => {
  const { plansId } = req.body;
  

  if (!plansId) {
    return res.status(400).json({ message: "Plan ID is required" });
  }
  try {
    // Check if the user already purchased the plan
    const userPurchaseQuery = "SELECT UserId, PlanId,payment_status FROM Payments WHERE UserId = ?";
    db.query(userPurchaseQuery, [req.user.UserId], async (err, userPurchase) => {
      if (err) return res.status(500).json({ message: "Error mysqli", error: err.message });




      if (userPurchase.length > 0 && userPurchase.payment_status=="PENDING") {
        return res.status(409).json({ message: "Plan already purchased but payment is pending" });
      }
      
      if (userPurchase.length > 0 && userPurchase.payment_status=="SUCCESS") {
        return res.status(409).json({ message: "Plan already purchased" });
      }

      // Fetch plan details
      const planQuery = "SELECT `PlanId`, `PlanFee`, `PlanState` FROM Plans WHERE PlanId = ?";
      db.query(planQuery, [plansId], async (err, plansResult) => {
        if (err) return res.status(500).json({ message: "Error mysqli", error: err.message });

        if (plansResult.length === 0) {
          return res.status(404).json({ message: "Plan not found" });
        }

        const planData = plansResult[0];
        if (planData.PlanState === 0) {
          return res.status(409).json({ message: "Plan is already active" });
        }

        // Create Cashfree order
        try {
          const orderRequest = {
            order_amount: planData.PlanFee,
            order_currency: "INR",
            order_id: await generateOrderId(),
            customer_details: {
              customer_id: req.user.UserId.toString(),
              customer_phone: req.user.phone || "0000000000",
              customer_name: req.user.name || "Unknown User",
            },
            order_meta: {
              return_url: "http://localhost:5000/show/Payments/info"
            }
          };

          const response = await Cashfree.PGCreateOrder("2023-08-01", orderRequest);
          const data = response.data;


          // Prepare SQL query and values
          const query = `
            INSERT INTO Payments (
              UserId, PlanId, order_currency, order_id, payment_method, 
              is_captured, payment_completion_time, payment_currency, bank_reference, 
              cf_payment_id, order_amount, gateway_name, gateway_order_id, 
              gateway_payment_id, payment_group, payment_message, payment_status, 
              payment_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;

          const values = [
            req.user.UserId,
            plansId,
            data.order_currency || "INR",
            data.order_id,
            JSON.stringify(data.payment_method || {}),
            data.is_captured ? 1 : 0,
            data.payment_completion_time || "0.0.0.0.0",
            data.payment_currency || "INR",
            data.bank_reference || "0000000",
            data.cf_payment_id || "000000",
            data.order_amount || 0,
            data.payment_gateway_details?.gateway_name || "Cashfree",
            data.payment_gateway_details?.gateway_order_id || "0",
            data.payment_gateway_details?.gateway_payment_id || "0",
            data.payment_group || "0",
            data.payment_message || "No message",
            data.order_status || "active",
            data.payment_time || "0",
          ];

          db.query(query, values, (err, result) => {
            if (err) {
              return res.status(500).json({ message: "Error mysqli", error: err.message });
            }
            res.json(response.data);
            
          });

        } catch (error) {
          res.status(500).json({ message: "Error mysqli", error: err.message });
        }
      });
    });
  } catch (error) {
    res.status(500).json({ message: "Error mysqli", error: err.message });
  }
});



router.post('/verify4', userAuth, async (req, res) => {
  const { orderIddd, PlanId } = req.body;
  const user = req.user.UserId;

  try {
    // Fetch payment details from Cashfree
    const response = await Cashfree.PGOrderFetchPayments("2023-08-01", orderIddd);

    const data = response.data[0];

    // Define the SQL query for updating the Payments table
    const query = `
      UPDATE Payments 
      SET 
        payment_method = ?, 
        is_captured = ?, 
        payment_completion_time = ?, 
        payment_currency = ?, 
        bank_reference = ?, 
        cf_payment_id = ?, 
        order_amount = ?, 
        gateway_name = ?, 
        gateway_order_id = ?, 
        gateway_payment_id = ?, 
        payment_group = ?, 
        payment_message = ?, 
        payment_status = ?, 
        payment_time = ? 
      WHERE 
        UserId = ? 
        AND PlanId = ? 
        AND order_id = ?
    `;

    // Prepare the values for updating
    const values = [
      
      JSON.stringify(data.payment_method),
      data.is_captured ? 1 : 0,
      data.payment_completion_time,
      data.payment_currency,
      data.bank_reference,
      data.cf_payment_id,
      data.order_amount,
      data.payment_gateway_details.gateway_name,
      data.payment_gateway_details.gateway_order_id,
      data.payment_gateway_details.gateway_payment_id,
      data.payment_group,
      data.payment_message,
      data.payment_status,
      data.payment_time,
      data.user || user, // Replace with actual UserId from your system if available
      data.PlanId || PlanId || 1, // Replace with actual PlanId from your system if available
      data.order_id,
    ];

    // Update data in the database
    db.query(query, values, (err, result) => {
      if (err) {
        return res.status(500).json({ message: "Error mysqli", error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'No matching record found to update' });
      }
      res.json({ message: 'Payment updated successfully', result });
    });

  } catch (error) {
res.status(500).json({ message: "Error mysqli", error: err.message });  }
});
///run 



router.post('/verify4', userAuth, async (req, res) => {
  
  const { orderIddd, PlanId } = req.body;
  const user = req.user.UserId;

  try {
    // Fetch payment details from Cashfree
    const response = await Cashfree.PGOrderFetchPayments("2023-08-01", orderIddd);

    const data = response.data[0];

    // Define the SQL query for updating the Payments table
    const query = `
      UPDATE Payments 
      SET 
        payment_method = ?, 
        is_captured = ?, 
        payment_completion_time = ?, 
        payment_currency = ?, 
        bank_reference = ?, 
        cf_payment_id = ?, 
        order_amount = ?, 
        gateway_name = ?, 
        gateway_order_id = ?, 
        gateway_payment_id = ?, 
        payment_group = ?, 
        payment_message = ?, 
        payment_status = ?, 
        payment_time = ? 
      WHERE 
        UserId = ? 
        AND PlanId = ? 
        AND order_id = ?
    `;

    // Prepare the values for updating
    const values = [
      
      JSON.stringify(data.payment_method),
      data.is_captured ? 1 : 0,
      data.payment_completion_time,
      data.payment_currency,
      data.bank_reference,
      data.cf_payment_id,
      data.order_amount,
      data.payment_gateway_details.gateway_name,
      data.payment_gateway_details.gateway_order_id,
      data.payment_gateway_details.gateway_payment_id,
      data.payment_group,
      data.payment_message,
      data.payment_status,
      data.payment_time,
      data.user || user, // Replace with actual UserId from your system if available
      data.PlanId || PlanId || 1, // Replace with actual PlanId from your system if available
      data.order_id,
    ];

    // Update data in the database
    db.query(query, values, (err, result) => {
      if (err) {
        return res.status(500).json({ message: "Error mysqli", error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'No matching record found to update' });
      }
      res.json({ message: 'Payment updated successfully', result });
    });

  } catch (error) {
    res.status(500).json({ message: "Error mysqli", error: err.message });
  }
});


router.post("/payment/create", async (req, res) => {
  const { amount, currency, customer_id } = req.body;

  try {
    const response = await axios.post(
      "https://sandbox.cashfree.com/pg/orders",
      {
        order_id: `order_${Date.now()}`,
        order_amount: amount,
        order_currency: currency,
        customer_details: {
          customer_id,
          customer_email: "customer@example.com",
          customer_phone: "9999999999",
        },
        order_meta: {
              return_url: "http://localhost:5000/show/Payments/info",
             notify_url: "https://play.svix.com/in/e_qfyp0wHir7PPUchGH9mL5R5ALqc/",
            },
      },
      {
        headers: {
          "x-api-version": "2022-01-01",
          "x-client-id": config.cashfreeXClientId,
          "x-client-secret": config.cashfreeXClientSecret,
          "Content-Type": "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (err) {
    res.status(500).json({ message: "Error mysqli", error: err.message });
  }
});



router.post('/payment/v6', userAuth, userDetailsExist,async (req, res) => {
  const { plansId } = req.body;
  

  if (!plansId) {
    return res.status(400).json({ message: "Plan ID is required" });
  }
  try {
    // Check if the user already purchased the plan
    const userPurchaseQuery = "SELECT UserId, PlanId,payment_status FROM Payments AS pay WHERE UserId = ? and payment_status= ?";
    db.query(userPurchaseQuery, [req.user.UserId,"SUCCESS"], async (err, userPurchase) => {
      if (err) return res.status(500).json({ message: "Error mysqli", error: err.message });
      
      
      
  if (userPurchase.length > 0 && userPurchase[0].payment_status=="PENDING") {
        return res.status(409).json({ message: "Plan already purchased but payment is pending" });
      }
      
      if (userPurchase.length > 0 && userPurchase[0].payment_status=="SUCCESS") {
        return res.status(409).json({ message: "Plan already purchased" });
      }

      // Fetch plan details
      const planQuery = "SELECT `PlanId`, `PlanFee`, `PlanState` FROM Plans WHERE PlanId = ?";
      db.query(planQuery, [plansId], async (err, plansResult) => {
        if (err) return res.status(500).json({ message: "Error mysqli", error: err.message });

        if (plansResult.length === 0) {
          return res.status(404).json({ message: "Plan not found" });
        }

        const planData = plansResult[0];
        if (planData.PlanState === 0) {
          return res.status(409).json({ message: "Plan is already active" });
        }

        // Create Cashfree order
        try {

    const response = await axios.post(
      "https://sandbox.cashfree.com/pg/orders",
      {
        order_amount: planData.PlanFee,
        order_currency: "INR",
         order_id: await generateOrderId(),
        customer_details: {
              customer_id: req.user.UserId.toString(),
              customer_phone: req.user.phone || "0000000000",
              customer_name: req.user.name || "Unknown User",
            },
        order_meta: {
              return_url: "http://localhost:5173/myplans",
             notify_url: "https://play.svix.com/in/e_qfyp0wHir7PPUchGH9mL5R5ALqc/",
            },
      },
      {
        headers: {
          "x-api-version": "2022-01-01",
          "x-client-id": config.cashfreeXClientId,
          "x-client-secret": config.cashfreeXClientSecret,
          "Content-Type": "application/json",
        },
      }
    );
          const data = response.data;

          // Prepare SQL query and values
          const query = `
            INSERT INTO Payments (
              UserId, PlanId, order_currency, order_id, payment_method, 
              is_captured, payment_completion_time, payment_currency, bank_reference, 
              cf_payment_id, order_amount, gateway_name, gateway_order_id, 
              gateway_payment_id, payment_group, payment_message, payment_status, 
              payment_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;

          const values = [
            req.user.UserId,
            plansId,
            data.order_currency || "INR",
            data.order_id,
            JSON.stringify(data.payment_method || {}),
            data.is_captured ? 1 : 0,
            data.payment_completion_time || "0.0.0.0.0",
            data.payment_currency || "INR",
            data.bank_reference || "0000000",
            data.cf_payment_id || "000000",
            data.order_amount || 0,
            data.payment_gateway_details?.gateway_name || "Cashfree",
            data.payment_gateway_details?.gateway_order_id || "0",
            data.payment_gateway_details?.gateway_payment_id || "0",
            data.payment_group || "0",
            data.payment_message || "No message",
            data.order_status || "active",
            data.payment_time || "0",
          ];

          db.query(query, values, (err, result) => {
            if (err) {
              return res.status(500).json({ message: "Error mysqli", error: err.message });
            }
            res.json({payment_link:response.data.payment_link});
            
          });

        } catch (error) {
       res.status(500).json({ message: "Error mysqli", error: err.message });        }
      });
    });
  } catch (error) {
    res.status(500).json({ message: "Error mysqli", error: err.message });
  }
});
























module.exports = router;