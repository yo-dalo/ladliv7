const express = require('express');
const config = require('../config/env');
const crypto = require('crypto');
const {addPayment} = require('../Controllers/PaymentController/AddPayment.js');
const {planAlreadyPurchased} = require('../Controllers/PlanContorller/PlanAllReadyParched.js');
const db = require('../db/Conn.js');
const {userAuth} =require("./auth");
const {userDetailsExist} =require("./userDetailsExist");
const {
  Cashfree
} = require('cashfree-pg');
const axios = require('axios');
const router = express.Router();


 Cashfree.XClientId = config.cashfreeXClientId;
Cashfree.XClientSecret = config.cashfreeXClientSecret;
Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;




function verify(ts, rawBody){
    const body = ts + rawBody
    console.log(rawBody);
    const secretKey = config.cashfreeXClientSecret;
    let genSignature = crypto.createHmac('sha256',secretKey).update(body).digest("base64");
    return genSignature
}
function verifyWebhookSignature(req, secretKey) {
  
  const signature = req.headers['x-webhook-signature'];
  const timestamp = req.headers['x-webhook-timestamp'];
  const signatureData = timestamp + JSON.stringify(req.body);

const generatedSignature = crypto.createHmac('sha256', secretKey) .update(signatureData, 'utf8') .digest('base64');
  return generatedSignature === signature;
}
function verifyWebhookSignature_v1(req, secretKey) {
    const signature = req.headers['x-webhook-signature'];
    const timestamp = req.headers['x-webhook-timestamp'];
    
    // Use rawBody instead of JSON.stringify(req.body)
    const body = timestamp + req.rawBody;

    const generatedSignature = crypto
        .createHmac('sha256', secretKey)
        .update(body)
        .digest('base64');

    if (generatedSignature === signature) {
        // Signature verified successfully
        return true;
    } else {
        console.log('Signature verification failed');
        console.log('Generated:', generatedSignature);
        console.log('Received:', signature);
        return false;
    }
}


router.post('/webhook', (req, res) => {
  const secretKey =  config.cashfreeXClientSecret;
    

  if (verifyWebhookSignature(req, secretKey)) {
      
const data = req?.body;
console.log(data);
const order = req?.body?.data?.order;
const payment = req?.body?.data?.payment;
const customer_details = req?.body?.data?.customer_details;
const payment_gateway_details = req?.body?.data?.payment_gateway_details;
        
  try {
    const query = `
      UPDATE Payments 
      SET 
        payment_method = ?, 
        is_captured = ?, 
        payment_completion_time = ?, 
        payment_currency = ?, 
        bank_reference = ?, 
        cf_payment_id = ?, 
        order_amount = ?, 
        gateway_name = ?, 
        gateway_order_id = ?, 
        gateway_payment_id = ?, 
        payment_group = ?, 
        payment_message = ?, 
        payment_status = ?, 
        payment_time = ? 
      WHERE 
        UserId = ? 
        AND order_id = ?
    `;

        const values = [

      JSON.stringify(payment.payment_method),
      data.is_captured ? 1 : 1,
      payment.payment_time,
      payment.payment_currency,
      payment.bank_reference,
      payment.cf_payment_id,
      order.order_amount,
      payment_gateway_details.gateway_name,
      payment_gateway_details.gateway_order_id,
      payment_gateway_details.gateway_payment_id,
      payment.payment_group,
      payment.payment_message,
      payment.payment_status,
      payment.payment_time,
      customer_details.customer_id || user, // Replace with actual UserId from your system if available
      //data.PlanId || PlanId || 1, // Replace with actual PlanId from your system if available
      order.order_id,
    ];

    // Update data in the database
    db.query(query, values, (err, result) => {
      if (err) {
        console.log({ error: 'Database error', details: err.message });
        return res.status(500).json({ error: 'Database error', details: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'No matching record found to update' });
      }
            console.log("all dune");
    ///  res.json({ message: 'Payment updated successfully', result });

    });

  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch order or update payment', details: error.message });
    console.log("err in try");
  }
    //res.sendStatus(200);
    
  } else {
    res.sendStatus(410);
    
    console.log('not ok verifyWebhookSignature');
  }
});




router.post('/webhook_v1', (req, res) => {
  const secretKey =  config.cashfreeXClientSecret;

  if (verifyWebhookSignature(req, secretKey)) {
    
        res.sendStatus(200);
        
  } else {
    res.sendStatus(400);
  }
});
router.post('/webhook_v2', (req, res) => {
  const secretKey =  config.cashfreeXClientSecret;

  if (verifyWebhookSignature(req, secretKey)) {
        console.log('Webhook signature is valid! v2')
        res.sendStatus(200);
  } else {
    console.log('Webhook signature is invalid! v2')
    res.sendStatus(400);
    
  }
});





router.post('/webhook_v3', function(req, res) {
    
    const ts = req.headers["x-webhook-timestamp"]
    const signature = req.headers["x-webhook-signature"]
   // console.log("ts --> ", ts);
   // console.log("expected sign --> ", signature);
    const genSignature = verify(ts, req.rawBody)
    if(signature === genSignature){
        res.send('OK')
        console.log('Webhook signature is valid! v3')
    } else {
      console.log('Webhook signature is invalid! v3')
        res.send("failed")
    } 
})


router.post('/webhook_v5', function (req, res) {
  try {
    // Verify the webhook signature
    Cashfree.PGVerifyWebhookSignature(
      req.headers["x-webhook-signature"],
      req.body.toString(),
      req.headers["x-webhook-timestamp"]
    );

    // If verification is successful, process the webhook payload
    const webhookData = JSON.parse(req.body.toString());
    console.log('Webhook verified. Payload:', webhookData);

  

    res.sendStatus(200);
  } catch (err) {
    console.error('Webhook verification failed:', err.message);
    res.sendStatus(400);
  }
});


router.post('/webhook_v6', (req, res) => {
    const CASHFREE_SECRET_KEY = config.cashfreeXClientSecret; // Replace with your actual secret key
    const receivedSignature = req.headers['x-cashfree-signature']; // Get the signature from the header
    const requestBody = JSON.stringify(req.body); // Convert the request body to a string

    // Step 1: Construct the expected signature
    const expectedSignature = crypto
        .createHmac('sha256', CASHFREE_SECRET_KEY)
        .update(requestBody)
        .digest('base64');

    // Step 2: Compare the signatures
    if (receivedSignature === expectedSignature) {
        // Signature is valid!  Process the webhook data
        console.log('Webhook signature is valid!v6');
        console.log('Webhook Data:', req.body);
        // YOUR LOGIC HERE: Update order status, send confirmation emails, etc.
        res.status(200).send('Webhook received and processed.');
    } else {
        // Signature is invalid!  Reject the request
        console.error('Webhook signature is invalid! v6');
        res.status(400).send('Invalid signature.');
    }
});






router.post('/webhook_v7', async function (req, res) {
try {
await Cashfree.PGVerifyWebhookSignature(req.headers["x-webhook-signature"], req.body, req.headers["x-webhook-timestamp"])
console.log("ok")
} catch (err) {
console.log(err.message)
}
})


router.post('/webhook_v8', async function (req, res) {

const webhookSignature = "/DuNI2m0bCcXu9DJnrN1p895T+VJBzWzHO2E+PJNwU8="; // Signature received from Cashfree 
const signatureData = '1736143929{"data":{"link_amount":"1.00","link_currency":"INR","link_minimum_partial_amount":null,"link_amount_paid":"1.00","link_purpose":"Payment Requested by OFB Pvt Ltd","link_notes":{},"link_created_at":"2025-01-06T11:40:14+05:30","customer_details":{"customer_phone":"9953206832","customer_email":"yuva9.finance@gmail.com","customer_name":"DZAF JSLNSJJWX"},"link_meta":{"notify_url":"https://webhook.site/621a7b39-ec3f-4a9b-b8d5-30eadd28f4e1","upi_intent":false,"return_url":"http://localhost:9000/callback/cashfree/6229534309527592901?linkId=TESTH8ZQSW4QF8","payment_methods":null},"cf_link_id":6292328,"link_id":"TESTH8ZQSW4QF8","link_url":"https://payments-test.cashfree.com/links/o7tipmu0mkdg","link_expiry_time":"2025-01-11T11:40:13+05:30","order":{"order_id":"CFPay_o7tipmu0mkdg_1bj7n81mlc7","order_expiry_time":"2025-01-06T11:51:49+05:30","order_hash":"YK2H8niSIVFWoHephcDb","order_amount":"1.00","transaction_id":5114915596820,"transaction_status":"SUCCESS"},"link_status":"PAID","link_partial_payments":false,"link_auto_reminders":false,"link_notify":{"send_sms":false,"send_email":false}},"type":"PAYMENT_LINK_EVENT","version":1,"event_time":"2025-01-06T11:42:09+05:30"}';

const secretKey = '079f1770cc7515661e654158ac9c74f47eaae053'; // Replace with your Secret Key 
const computedSignature = crypto.createHmac('sha256', secretKey) .update(signatureData, 'utf8') .digest('base64');

console.log("Webhook Signature: " + webhookSignature); console.log("Computed Signature: " + computedSignature);

if (computedSignature === webhookSignature) { console.log("WEBHOOK_VALIDATION_SUCCESS"); } else { console.log("WEBHOOK_VALIDATION_FAILED"); }

})
router.post('/webhook_v9', async function (req, res) {
  const secretKey =  config.cashfreeXClientSecret;

    const webhookSignature = req.headers['x-webhook-signature'];
    const timestamp = req.headers['x-webhook-timestamp'];
    
console.log(req.body.toString());
//const webhookSignature = "WyPeZz9YMwnsmmwhfu1h5rqW0D0dunGhNOKXPX2RZhU="; // Signature received from Cashfree 
const signatureData = timestamp+'{"data":{"order":{"order_id":"order_1740123003376","order_amount":11000.00,"order_currency":"INR","order_tags":null},"payment":{"cf_payment_id":"5114916291363","payment_status":"SUCCESS","payment_amount":11000.00,"payment_currency":"INR","payment_message":"Simulated response message","payment_time":"2025-02-21T13:00:13+05:30","bank_reference":"1234567890","auth_id":null,"payment_method":{"upi":{"channel":null,"upi_id":"testsuccess@gocash"}},"payment_group":"upi"},"customer_details":{"customer_name":null,"customer_id":"29","customer_email":"customer@example.com","customer_phone":"9999999999"},"payment_gateway_details":{"gateway_name":"CASHFREE","gateway_order_id":"2189953881","gateway_payment_id":"5114916291363","gateway_status_code":null,"gateway_order_reference_id":"null","gateway_settlement":"CASHFREE","gateway_reference_name":null},"payment_offers":null},"event_time":"2025-02-21T13:00:36+05:30","type":"PAYMENT_SUCCESS_WEBHOOK"}';

//console.log(signatureData);

var jsonData = req.body;
jsonData.data.payment.payment_amount = Number(jsonData.data.payment.payment_amount).toFixed(2);
jsonData.data.order.order_amount = Number(jsonData.data.order.order_amount).toFixed(2);
//console.log(JSON.stringify(jsonData)); 
const signatureData2 = timestamp+JSON.stringify(jsonData)

//console.log(signatureData);
//console.log(signatureData2);
//console.log( signatureData===signatureData2);

//const secretKey = 'cfsk_ma_test_cf57519969323653b298b7aa7ad49be1_4ecb6d1c'; // Replace with your Secret Key 
const computedSignature = crypto.createHmac('sha256', secretKey) .update(signatureData, 'utf8') .digest('base64');

//console.log("Webhook Signature: " + webhookSignature); console.log("Computed Signature: " + computedSignature);

if (computedSignature === webhookSignature) { 
  console.log("WEBHOOK_VALIDATION_SUCCESS");
  res.send('ok')
  } else { 
    console.log("WEBHOOK_VALIDATION_FAILED"); 
    
    res.send('not ok')
  }

})

app.post('/webhook_v10', function(req, res) {
  console.log(req.rawBody);
  const ts = req.headers["x-webhook-timestamp"]  
  const signature = req.headers["x-webhook-signature"]
  const currTs = Math.floor(new Date().getTime() / 1000)
  if(currTs - ts > 30000){
    res.send("Failed")
  }  
  genSign = verify(ts, req.rawBody)
  matched = genSign === signature
  console.log(genSign, signature, matched)
  res.send(matched)
})








module.exports = router;