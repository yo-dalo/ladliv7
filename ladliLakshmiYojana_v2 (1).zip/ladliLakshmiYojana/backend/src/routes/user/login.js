const express = require('express');

const db = require("../../db/Conn");

const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const config = require('../../config/env');
const router = express.Router();
const {phoneNumberIsExist} = require('../../Utility/PhoneNumberIsExist');
const {chackOtpIs_Valid} = require('../../Utility/ChackOtpIs_Valid');

const SECRET_KEY = config.userjwtkey; // R
const USERCOOKIE_NAME = config.userAuthToken;




async function sendOtpViaSMS(phone, otp) {
  const API_KEY = config.FAST2SMSOTP; // Replace with your Fast2SMS API key
  const message = `Your OTP for logging in to LLY account is   ${otp}.Valid for the next 5 min.`;

  try {
    const response = await axios.post('https://www.fast2sms.com/dev/bulkV2', {
      route: 'q', // Transactional route
      message: message,
      language: 'english',
      numbers: phone,
    }, {
      headers: {
        'authorization': API_KEY,
        'Content-Type': 'application/json',
      },
    });

    return response.data;
  } catch (error) {
    console.error('Error sending OTP:', error.message);
    return null;
  }
}

router.post('/login/otp', (req, res) => {
  const { phone } = req.body;
  const User_id = 11;

  // Validate phone number
  if (!phone || !/^\d{10}$/.test(phone)) {
    return res.status(400).json({ error: 'Invalid phone number' });
  }

  // Generate a random 6-digit OTP
  const otp = crypto.randomInt(100000, 999999);
  const expiry = new Date(Date.now() + 10 * 60 * 100); // Expire after 1 minute

  // Delete any existing OTP for this phone number
  const deleteSql = "DELETE FROM `Otp` WHERE `Phone_number` = ?";
  db.query(deleteSql, [phone], (err, result) => {
    if (err) {
      
      return res.status(500).json({ error: 'Database error 1' });
    }

    // Insert the new OTP with expiration time
    const insertSql = "INSERT INTO `Otp` (`Phone_number`, `Otp`, `User_id`, `Expiry`) VALUES (?, ?, ?, ?)";
    db.query(insertSql, [phone, otp, User_id, expiry], async (err, result) => {
      if (err) {
        
        return res.status(500).json({ error: 'Database error 2' });
      }

      // Send OTP to the user via SMS
      const smsResponse = await sendOtpViaSMS(phone, otp);
      if (smsResponse && smsResponse.return) {
        res.json({ message: 'OTP generated and sent successfully', otp, User_id });
      } else {
        res.status(500).json({ error: 'Failed to send OTP via SMS' });
      }
    });
  });
});
router.post('/login/otp_1',phoneNumberIsExist,chackOtpIs_Valid, (req, res) => {
  const { phone } = req.body;
  const User_id = 1000;

  // Validate phone number
  if (!phone || !/^\d{10}$/.test(phone)) {
    return res.status(300).json({ error: 'Invalid phone number' });
  }

  // Generate a random 6-digit OTP
  const otp = crypto.randomInt(100000, 999999);
  const expiry = new Date(Date.now() + 3 * 60 * 1000); // Expire after 3 minutes
  // Delete any existing OTP for this phone number
  const deleteSql = "DELETE FROM `Otp` WHERE `Phone_number` = ?";
  db.query(deleteSql, [phone], (err, result) => {
    if (err) {
      
      return res.status(500).json({ error: 'Database error 1' });
    }

    // Insert the new OTP with expiration time
    const insertSql = "INSERT INTO `Otp` (`Phone_number`, `Otp`, `User_id`, `Expiry`) VALUES (?, ?, ?, ?)";
    db.query(insertSql, [phone, otp, User_id, expiry], (err, result) => {
      if (err) {
        
        return res.status(500).json({ error: 'Database error 2' });
      }

      res.json({ message: 'OTP generated successfully', otp, User_id });
      console.log(otp);
    });
  });
});










router.post('/logout', (req, res) => {
  const isProduction = config.cookia_deploy === 'deploy';
  
  res.clearCookie(USERCOOKIE_NAME, {
    path: '/',
    httpOnly: isProduction,
    secure: isProduction,
    sameSite: isProduction ? 'None' : 'Lax',
  });
  
  res.json({ message: 'User logged out successfully' });
});


    
  router.post('/login/v2', (req, res) => {
  const { phone, otp } = req.body;
  
  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and OTP are required' });
  }
  
  const fetchSql = `SELECT Otp, Expiry, Users.UserId, Users.UserName, Users.Phone, ud.DetailsId FROM Users LEFT JOIN Otp ON Otp.Phone_number = Users.Phone LEFT JOIN UserDetails ud ON ud.UserId = Users.UserId WHERE Users.Phone = ?;`;
  
  db.query(fetchSql, [phone], (err, results) => {
    if (err) {
      
      return res.status(500).json({ error: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: 'This Number no exist ' });
    }

    const record = results[0];
    
    // Check OTP expiry
    if (!record.Otp) {
      return res.status(400).json({ error: 'OTP has Not exist' });
    }
    if (new Date() > record.Expiry) {
      return res.status(400).json({ error: 'OTP has expired' });
    }

    // Validate OTP
    if (record.Otp !== otp) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    // Generate JWT token
    const token = jwt.sign({ phone, otp, UserId: record.UserId, name: record.UserName }, SECRET_KEY, { expiresIn: '1d' });
    
    
      const isProduction = config.cookia_deploy === 'deploy';

    res.cookie(config.userAuthToken, token, {
  path: '/',
  httpOnly: isProduction, // Set to true in production
  secure: isProduction, // Only enable secure in production
  sameSite: isProduction ? 'None' : 'Lax', // Adjust based on the environment
  maxAge:60 * 60 * 1000 ,
}).json({
  message: "User login successfully",
  loginData: {
    detailsId: record.DetailsId,
    phone: record.Phone,
    userId: record.UserId,
    name: record.UserName
  }
});
  
    
  });
});






module.exports = router;