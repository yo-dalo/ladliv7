const express = require('express');
const db = require("../../db/Conn");
const {userAuth} =require("../../Utility/auth");
const router = express.Router();


//get user profile details  user ,UserDetails,who has bay plain
///SELECT u.*,ud.*,p.*,pl.* FROM Users u LEFT JOIN UserDetails ud ON u.UserId = ud.UserId left join Payments p on p.UserId=u.UserId left join Plans pl on pl.PlanId=p.PlanId WHERE u.UserId = 24;


router.get('/show/user/profile',userAuth, (req, res) => {
  console.log( req.user)
  
  const sqli = "SELECT * FROM Users WHERE UserId  = ?";
  db.query(sqli, [req.user.UserId], (err, results) => {
    if (err) {
      
      return res.status(500).json({ error: 'Database error while getting OTP' });
    }

  console.log(req.user.UserId);
  
    res.json({ message: results });
});
});


router.get('/show/user/paymentpeceipt', userAuth,(req, res) => {
 // console.log( req.user)

const sqli = ` SELECT 
    pay.PaymentId,
    pay.UserId,
    pay.PlanId,
    pay.payment_status,
    pay.payment_time,
    pay.order_amount,
    p.PlanName,
    p.PlanDuration,
    p.PlanFee,
    p.PlanReturnPrice,
    p.PlanState,
    p.PlanInformation,
    u.UserName,
    u.Email,
    u.Phone,
    u.Address
FROM Payments AS pay
LEFT JOIN Plans AS p ON pay.PlanId = p.PlanId
LEFT JOIN Users AS u ON pay.UserId = u.UserId
WHERE pay.UserId = ? AND  pay.payment_status = ? ;`
  
 // AND (pay.payment_status = ? OR pay.payment_status = ?)
// "PENDING","SUCCESS"
    db.query(sqli, [req.user.UserId,"SUCCESS"], (err, results) => {
    if (err) {
      
      return  res.status(500).json({ message: "Error mysqli", error: err.message });
    }
    if(results.length===0){
      return res.status(400).json({ error: 'no data found ' });
    }

  
  
    res.status(200).json({ message: results });
});
});

router.get('/show/user/have/plans',userAuth, (req, res) => {
 // console.log( req.user)
const sqli = ` SELECT p.PlanId, p.PlanName, p.PlanDuration, p.PlanFee, p.PlanReturnPrice, p.PlanState, p.PlanInformation
FROM Plans AS p
JOIN Payments AS pay ON p.PlanId = pay.PlanId
WHERE pay.UserId = ? and pay.payment_status = ? or pay.payment_status = ? `;
    db.query(sqli, [req.user.UserId,"PENDING","SUCCESS"], (err, results) => {
    if (err) {
      
      return  res.status(500).json({ message: "Error mysqli", error: err.message });
    }
    
  
    res.status(200).json({ results });
});
});











module.exports = router;