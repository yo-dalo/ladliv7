const express = require('express');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require("../../db/Conn");
const {userAuth} =require("../../Utility/auth");
const router = express.Router();


router.get("/show/plans",(req,res)=>{
 
 const sqli = "SELECT * FROM `Plans`"
 
 db.query(sqli, (err, results) => {
   if (err) {
      
      return res.status(500).json({ message: "Error mysqli", error: err.message });
    }

      res.status(200).json({ results });
   
   
 })
 
  
})

router.get("/show/plans/:id",userAuth,(req,res)=>{
  
 const userId = req.params.id;
 
 const sqli = "SELECT * FROM `Plans` Where PlanId = ?"
 //const sqli = "SELECT * FROM `Users` Where userId = ?"
 
 db.query(sqli,[userId],(err, results) => {
   if (err) {
      
      return res.status(500).json({ message: "Error mysqli", error: err.message });
    }
    const result = { ...results[0], name: req.user.name };

  res.status(200).json({result});

   
   
 })
 
  
})



module.exports = router;