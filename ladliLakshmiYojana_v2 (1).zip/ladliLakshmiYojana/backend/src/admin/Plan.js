const express = require('express');
const db = require("../db/Conn");
const {userAuth} =require("../Utility/auth");
const router = express.Router();


// Create a new plan
router.post("/admin/plans", (req, res) => {
  const { PlanName, PlanDuration, PlanFee, PlanReturnPrice, PlanState, PlanInformation } = req.body;

  const query = `INSERT INTO Plans (PlanName, PlanDuration, PlanFee, PlanReturnPrice, PlanState, PlanInformation) 
                 VALUES (?, ?, ?, ?, ?, ?)`;

  db.query(
    query,
    [PlanName, PlanDuration, PlanFee, PlanReturnPrice, PlanState, PlanInformation],
    (err, result) => {
      if (err) {
      return res.status(500).json({ error: `Database error Lever ${err}`});
      } else {
        res.status(201).json({ message: "Plan created successfully!", planId: result.insertId });
      }
    }
  );
});

// Edit a plan
router.put("/admin/plans/:id", (req, res) => {
  const { id } = req.params;
  const { PlanName, PlanDuration, PlanFee, PlanReturnPrice, PlanState, PlanInformation } = req.body;

  const query = `UPDATE Plans 
                 SET PlanName = ?, PlanDuration = ?, PlanFee = ?, PlanReturnPrice = ?, PlanState = ?, PlanInformation = ? 
                 WHERE PlanId = ?`;

  db.query(
    query,
    [PlanName, PlanDuration, PlanFee, PlanReturnPrice, PlanState, PlanInformation, id],
    (err, result) => {
      if (err) {
      return res.status(500).json({ error: `Database error  ${err}`});
      } else if (result.affectedRows === 0) {
        res.status(404).json({ message: "Plan not found" });
      } else {
        res.status(200).json({ message: "Plan updated successfully!" });
      }
    }
  );
});

// Get all plans
router.get("/admin/plans", (req, res) => {
  const query = "SELECT * FROM Plans";

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: `Database error  ${err}`});
    } else {
      res.status(200).json(results);
    }
  });
});

// Get plan by ID
router.get("/admin/plans/:id", (req, res) => {
  const { id } = req.params;

  const query = "SELECT * FROM Plans WHERE PlanId = ?";

  db.query(query, [id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: `Database error  ${err}`});
    } else if (results.length === 0) {
      res.status(404).json({ message: "Plan not found" });
    } else {
      res.status(200).json(results[0]);
    }
  });
});


router.delete('/admin/plans/delete/:id', (req, res) => {
    const userId = req.params.id;
    const sql = `DELETE FROM Plans WHERE PlanId = ?`;

    db.query(sql, [userId], (err, result) => {
        if (err) {
            res.status(500).send({ error: err.message });
        } else if (result.affectedRows === 0) {
            res.status(404).send({ message: 'Plan not found' });
        } else {
            res.status(200).send({ message: 'Plan deleted successfully' });
        }
    });
});









module.exports = router;