export type Package = {
  name: string;
  price: number;
  invoiceDate: string;
  status: string;
};
