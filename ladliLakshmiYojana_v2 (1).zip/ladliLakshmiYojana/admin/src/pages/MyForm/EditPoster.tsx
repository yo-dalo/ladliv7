import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Axios from 'axios';
import Breadcrumb from '../../components/Breadcrumbs/Breadcrumb';

const EditPoster = () => {
  const { id } = useParams(); // Get poster ID from URL
  const [formData, setFormData] = useState({
    Img: '',
    Text: '',
    Status: '',
    index: '',
  });
  const [imageFile, setImageFile] = useState(null);

  // Fetch existing poster details by ID
  useEffect(() => {
    const fetchPoster = async () => {
      try {
        const response = await Axios.get(import.meta.env.VITE_API_URL+ `/api/posters/${id}`);
        setFormData({
          Img: response.data.Img,
          Text: response.data.Text,
          Status: response.data.Status,
          index: response.data.index,
        });
      } catch (error) {
        console.error('Error fetching poster details:', error);
      }
    };
    fetchPoster();
  }, [id]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image file selection
  const handleImageChange = (e) => {
    setImageFile(e.target.files[0]);
  };

  // Form submission handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
    if (imageFile) formDataToSend.append('Img', imageFile);
    formDataToSend.append('Text', formData.Text);
    formDataToSend.append('Status', formData.Status);
    formDataToSend.append('index', formData.index);

    try {
      await Axios.put(import.meta.env.VITE_API_URL+`/api/posters/${id}`, formDataToSend, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('Poster updated successfully!');
    } catch (error) {
      console.error('Error updating poster:', error);
      alert('Failed to update poster.');
    }
  };

  return (
    <>
      <Breadcrumb pageName="Edit Poster" />

      <div className="grid grid-cols-1 gap-9 sm:grid-cols-2">
        <div className="flex flex-col gap-9">
          <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="border-b border-stroke py-4 px-6.5 dark:border-strokedark">
              <h3 className="font-medium text-black dark:text-white">Edit Poster</h3>
            </div>
            <form onSubmit={handleSubmit} encType="multipart/form-data">
              <div className="p-6.5">
                {/* Image Upload */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Upload Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    className="w-full border border-stroke rounded py-3 px-5 dark:bg-form-input dark:text-white"
                    onChange={handleImageChange}
                  />
                </div>

                {/* Text Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Text</label>
                  <input
                    type="text"
                    name="Text"
                    placeholder="Enter poster text"
                    value={formData.Text}
                    onChange={handleChange}
                    className="w-full rounded border border-stroke py-3 px-5 dark:bg-form-input dark:text-white"
                    required
                  />
                </div>

                {/* Status Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Status</label>
                  <select
                    name="Status"
                    value={formData.Status}
                    onChange={handleChange}
                    className="w-full rounded border border-stroke py-3 px-5 dark:bg-form-input dark:text-white"
                  >
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                  </select>
                </div>

                {/* Index Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Index</label>
                  <input
                    type="number"
                    name="index"
                    placeholder="Enter index number"
                    value={formData.index}
                    onChange={handleChange}
                    className="w-full rounded border border-stroke py-3 px-5 dark:bg-form-input dark:text-white"
                    required
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="flex w-full justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90"
                >
                  Update Poster
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditPoster;