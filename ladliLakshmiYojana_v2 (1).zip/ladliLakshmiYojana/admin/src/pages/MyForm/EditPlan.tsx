import { useState, useEffect } from 'react';
import Axios from 'axios';
import { useParams } from 'react-router-dom';
import Breadcrumb from '../../components/Breadcrumbs/Breadcrumb';
import SelectGroupOne from '../../components/Forms/SelectGroup/SelectGroupOne';

const EditPlan = () => {
  const { planId } = useParams(); // Assuming planId is passed in URL
  const [formData, setFormData] = useState({
    PlanName: '',
    PlanDuration: '',
    PlanFee: '',
    PlanReturnPrice: '',
    PlanState: '',
    PlanInformation: '',
  });

  // Fetch the existing plan details when component mounts
  useEffect(() => {
    const fetchPlanData = async () => {
      try {
        const response = await Axios.get(import.meta.env.VITE_API_URL+ `/api/admin/plans/${planId}`);
        setFormData(response.data); // Fill form with existing plan data
      } catch (error) {
        console.error('Error fetching plan details:', error);
      }
    };

    if (planId) {
      fetchPlanData();
    }
  }, [planId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await Axios.put(import.meta.env.VITE_API_URL+`/api/admin/plans/${planId}`, formData);
      alert('Plan updated successfully!');
      console.log(response.data);
    } catch (error) {
      console.error('Error updating plan:', error);
    }
  };

  return (
    <>
      <Breadcrumb pageName="Edit Plan" />

      <div className="grid grid-cols-1 gap-9 sm:grid-cols-2">
        <div className="flex flex-col gap-9">
          {/* <!-- Edit Plan Form --> */}
          <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="border-b border-stroke py-4 px-6.5 dark:border-strokedark">
              <h3 className="font-medium text-black dark:text-white">Edit Plan</h3>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="p-6.5">
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Plan Name</label>
                  <input
                    type="text"
                    name="PlanName"
                    value={formData.PlanName}
                    onChange={handleChange}
                    placeholder="Enter Plan Name"
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Plan Duration (years)</label>
                  <input
                    type="number"
                    name="PlanDuration"
                    value={formData.PlanDuration}
                    onChange={handleChange}
                    placeholder="Enter Duration in Years"
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Plan Fee</label>
                  <input
                    type="number"
                    step="0.01"
                    name="PlanFee"
                    value={formData.PlanFee}
                    onChange={handleChange}
                    placeholder="Enter Plan Fee"
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Plan Return Price</label>
                  <input
                    type="number"
                    step="0.01"
                    name="PlanReturnPrice"
                    value={formData.PlanReturnPrice}
                    onChange={handleChange}
                    placeholder="Enter Return Price"
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Plan State</label>
                  <input
                    type="text"
                    name="PlanState"
                    value={formData.PlanState}
                    onChange={handleChange}
                    placeholder="Enter Plan State"
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-6">
                  <label className="mb-2.5 block text-black dark:text-white">Plan Information</label>
                  <textarea
                    rows={6}
                    name="PlanInformation"
                    value={formData.PlanInformation}
                    onChange={handleChange}
                    placeholder="Enter Plan Information"
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="flex w-full justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90"
                >
                  Update Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditPlan;