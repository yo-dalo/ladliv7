import { useState } from 'react';
import Axios from 'axios';
import Breadcrumb from '../../components/Breadcrumbs/Breadcrumb';

const AddPoster = () => {
  const [formData, setFormData] = useState({
    Img: '',
    Text: '',
    Status: '',
    index: '',
  });

  const [imageFile, setImageFile] = useState(null);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    setImageFile(e.target.files[0]);
  };

  // Form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
    formDataToSend.append('Img', imageFile);
    formDataToSend.append('Text', formData.Text);
    formDataToSend.append('Status', formData.Status);
    formDataToSend.append('index', formData.index);

    try {
      const response = await Axios.post(import.meta.env.VITE_API_URL+ '/api/posters', formDataToSend, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('Poster added successfully!');
    } catch (error) {
      console.error('Error adding poster:', error);
      alert('Failed to add poster.');
    }
  };

  return (
    <>
      <Breadcrumb pageName="Add Poster" />

      <div className="grid grid-cols-1 gap-9 sm:grid-cols-2">
        <div className="flex flex-col gap-9">
          <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="border-b border-stroke py-4 px-6.5 dark:border-strokedark">
              <h3 className="font-medium text-black dark:text-white">Add Poster</h3>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="p-6.5">
                {/* Image Upload */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Upload Image</label>
                  <input
                    type="file"
                    name="Img"
                    accept="image/*"
                    onChange={handleImageChange}
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5"
                  />
                </div>

                {/* Text Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Text</label>
                  <input
                    type="text"
                    name="Text"
                    placeholder="Enter poster text"
                    value={formData.Text}
                    onChange={handleChange}
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5"
                  />
                </div>

                {/* Status Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Status (1/0)</label>
                  <input
                    type="number"
                    name="Status"
                    placeholder="Enter status (1 for active, 0 for inactive)"
                    value={formData.Status}
                    onChange={handleChange}
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5"
                  />
                </div>

                {/* Index Input */}
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">Index</label>
                  <input
                    type="number"
                    name="index"
                    placeholder="Enter index"
                    value={formData.index}
                    onChange={handleChange}
                    required
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5"
                  />
                </div>

                <button type="submit" className="flex w-full justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90">
                  Add Poster
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddPoster;