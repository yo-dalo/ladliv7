import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import MyPosterTableTwo from '../components/Tables/MyPosterTableTwo';

const MyPoster = () => {
  return (
    <>
      <Breadcrumb pageName="My Poster" />

      <div className="flex flex-col gap-10">

        <MyPosterTableTwo />
      </div>
    </>
  );
};

export default MyPoster;
