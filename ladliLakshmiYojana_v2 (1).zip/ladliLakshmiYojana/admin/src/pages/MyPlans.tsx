import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import MyPlansTableThree from '../components/Tables/MyPlansTableThree';

const MyPlans = () => {
  return (
    <>
      <Breadcrumb pageName="My Plans" />

      <div className="flex flex-col gap-10">
        <MyPlansTableThree />
      </div>
    </>
  );
};

export default MyPlans;
