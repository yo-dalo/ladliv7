import { useEffect, useState } from "react";
import Axios from "axios";
import { useParams } from "react-router-dom";

interface UserProfile {
  UserId: number;
  UserName: string;
  FatherName: string;
  MotherName: string;
  DOB: string;
  Address: string;
  Email: string;
  Phone: string;
  District: string;
  State: string;
  Pincode: string;
  Age: number;
  Gender: string;
  profilePhoto: string | null;
  FamilyIdImg: string | null;
  AadhaarFrontImg: string | null;
  AadhaarBackImg: string | null;
  signatureImage: string | null;
}

const UserProfilePage = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const { userId } = useParams();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await Axios.get(
          `${import.meta.env.VITE_API_URL}/api/user/details/${userId}`
        );
        setUser(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  if (loading) {
    return <p>Loading user profile...</p>;
  }

  if (!user) {
    return <p>User not found.</p>;
  }

  return (
    <div className="container mx-auto p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-4">User Profile</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* User Basic Details */}
        <div>
          <h3 className="text-lg font-medium mb-2">Basic Details</h3>
          <p><strong>Name:</strong> {user.UserName}</p>
          <p><strong>Father's Name:</strong> {user.FatherName}</p>
          <p><strong>Mother's Name:</strong> {user.MotherName}</p>
          <p><strong>Date of Birth:</strong> {user.DOB}</p>
          <p><strong>Age:</strong> {user.Age}</p>
          <p><strong>Gender:</strong> {user.Gender}</p>
          <p><strong>Address:</strong> {user.Address}</p>
          <p><strong>District:</strong> {user.District}</p>
          <p><strong>State:</strong> {user.State}</p>
          <p><strong>Pincode:</strong> {user.Pincode}</p>
          <p><strong>Email:</strong> {user.Email}</p>
          <p><strong>Phone:</strong> {user.Phone}</p>
        </div>

        {/* User Images */}
        <div>
          <h3 className="text-lg font-medium mb-2">Images</h3>
          <div className="flex flex-col space-y-4">
            <div>
              <p><strong>Profile Photo:</strong></p>
              {user.profilePhoto ? (
                <img
                  src={"/api/images/"+user.profilePhoto}
                  alt="Profile"
                  className="w-full h-48 object-cover rounded"
                />
              ) : (
                <p>No Profile Photo Available</p>
              )}
            </div>
            <div>
              <p><strong>Aadhaar Front:</strong></p>
              {user.AadhaarFrontImg ? (
                <img
                  src={"/api/images/"+user.AadhaarFrontImg}
                  alt="Aadhaar Front"
                  className="w-full h-48 object-cover rounded"
                />
              ) : (
                <p>No Aadhaar Front Image Available</p>
              )}
            </div>
            <div>
              <p><strong>Aadhaar Back:</strong></p>
              {user.AadhaarBackImg ? (
                <img
                  src={"/api/images/"+user.AadhaarBackImg}
                  alt="Aadhaar Back"
                  className="w-full h-48 object-cover rounded"
                />
              ) : (
                <p>No Aadhaar Back Image Available</p>
              )}
            </div>
            <div>
              <p><strong>Family ID:</strong></p>
              {user.FamilyIdImg ? (
                <img
                  src={"/api/images/"+user.FamilyIdImg}
                  alt="Family ID"
                  className="w-full h-48 object-cover rounded"
                />
              ) : (
                <p>No Family ID Image Available</p>
              )}
            </div>
            <div>
              <p><strong>Signature:</strong></p>
              {user.signatureImage ? (
                <img
                  src={"/api/images/"+user.signatureImage}
                  alt="Signature"
                  className="w-full h-24 object-contain rounded"
                />
              ) : (
                <p>No Signature Available</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;