import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import MyUserTableThree from '../components/Tables/MyUserTableThree';

const Myuser = () => {
  return (
    <>
      <Breadcrumb pageName="My User" />

      <div className="flex flex-col gap-10">

        <MyUserTableThree />
      </div>
    </>
  );
};

export default Myuser;
