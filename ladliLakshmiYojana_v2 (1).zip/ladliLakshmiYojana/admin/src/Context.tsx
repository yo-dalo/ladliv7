import React, { createContext, useState, useEffect, ReactNode } from "react";
import axios from "axios";

// Define the context type
interface AuthContextType {
  loading: boolean;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
  delectcommeny: number;
  setDelectcommeny: React.Dispatch<React.SetStateAction<number>>;
  x: {
    userId: string | null;
    name: string;
    phone: string;
    detailsId: string | null;
    isLogin: boolean;
  };
  setX: React.Dispatch<React.SetStateAction<{
    userId: string | null;
    name: string;
    phone: string;
    detailsId: string | null;
    isLogin: boolean;
  }>>;
  clearX: () => void;
}

// Create the context with the defined type
export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Define the props for AuthProvider
interface AuthProviderProps {
  children: ReactNode;
}

// Provide the context
export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [delectcommeny, setDelectcommeny] = useState<number>(0);

  const [x, setX] = useState<{
    userId: string | null;
    name: string;
    phone: string;
    detailsId: string | null;
    isLogin: boolean;
  }>({
    userId: null,
    name: "",
    phone: "",
    detailsId: null,
    isLogin: false,
  });

  const clearX = () => {
    setX((x) => ({ ...x, userId: null }));
    setX((x) => ({ ...x, name: "" }));
    setX((x) => ({ ...x, phone: "" }));
    setX((x) => ({ ...x, isLogin: false }));
  };

  useEffect(() => {
    chacker();
  }, []);

  const chacker = async () => {
    try {
      const response = await axios.get(
        import.meta.env.VITE_API_URL + "/api/verify/admin/cookia",
        { withCredentials: true }
      );

      setX((x) => ({ ...x, userId: response.data.userId }));
      setX((x) => ({ ...x, name: response.data.name }));
      setX((x) => ({ ...x, phone: response.data.phone }));
      setX((x) => ({ ...x, isLogin: true }));
    } catch (error:any) {
      clearX();
      console.error("Error fetching user data:", error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        loading,
        setLoading,
        delectcommeny,
        setDelectcommeny,
        x,
        setX,
        clearX,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};